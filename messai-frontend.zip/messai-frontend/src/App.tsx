import { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  ArrowRight,
  BarChart3,
  Camera,
  ChevronRight,
  Flame,
  LayoutGrid,
  Menu,
  MessageSquare,
  Play,
  ShieldCheck,
  Sparkles,
  Star,
  X
} from "lucide-react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

function useMousePosition() {
  const [pos, setPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const onMove = (e: MouseEvent) => setPos({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", onMove, { passive: true });
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return pos;
}

function useInView<T extends HTMLElement>(threshold = 0.15) {
  const ref = useRef<T | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el || isVisible) return;

    const obs = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setIsVisible(true);
          obs.disconnect();
        }
      },
      { threshold }
    );

    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold, isVisible]);

  return [ref, isVisible] as const;
}

function useCountUp(target: number, duration = 900, start = false) {
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!start) return;

    let current = 0;
    const steps = Math.max(1, Math.round(duration / 16));
    const inc = target / steps;

    const id = window.setInterval(() => {
      current += inc;
      if (current >= target) {
        setValue(target);
        window.clearInterval(id);
        return;
      }
      setValue(Math.round(current));
    }, 16);

    return () => window.clearInterval(id);
  }, [target, duration, start]);

  return value;
}

const tooltipProps = {
  contentStyle: {
    background: "#0D0F12",
    border: "1px solid #1A1D23",
    borderRadius: 12,
    color: "#F0F2F5"
  },
  cursor: { stroke: "rgba(0,255,148,0.18)", strokeWidth: 1 }
};

export default function App() {
  const { x, y } = useMousePosition();
  const [menuOpen, setMenuOpen] = useState(false);
  const [pricingYearly, setPricingYearly] = useState(false);
  const [activeNav, setActiveNav] = useState("Home");
  const [dashTab, setDashTab] = useState<"Week" | "Month">("Week");
  const [underline, setUnderline] = useState({ left: 0, width: 0, opacity: 0 });

  const navWrapRef = useRef<HTMLDivElement | null>(null);
  const navItemRefs = useRef<Array<HTMLButtonElement | null>>([]);

  const nav = useMemo(
    () => [
      { label: "Home", id: "home" },
      { label: "How it works", id: "how" },
      { label: "Features", id: "features" },
      { label: "Pricing", id: "pricing" },
      { label: "FAQ", id: "footer" }
    ],
    []
  );

  const stats = useMemo(
    () => [
      { label: "Meals scanned", value: 10000, suffix: "+" },
      { label: "Detection accuracy", value: 98, suffix: ".2%" },
      { label: "Students", value: 500, suffix: "+" }
    ],
    []
  );

  const marquee = useMemo(
    () => [
      "10,000+ Meals Scanned",
      "98.2% Detection Accuracy",
      "500+ Students",
      "15+ College Messes",
      "4.9★ Average Rating",
      "3s Average Scan Time"
    ],
    []
  );

  const weekCalories = useMemo(
    () => [
      { day: "Mon", calories: 1780 },
      { day: "Tue", calories: 1920 },
      { day: "Wed", calories: 1650 },
      { day: "Thu", calories: 2080 },
      { day: "Fri", calories: 1840 },
      { day: "Sat", calories: 2200 },
      { day: "Sun", calories: 1960 }
    ],
    []
  );

  const monthCalories = useMemo(
    () => [
      { day: "W1", calories: 12450 },
      { day: "W2", calories: 13210 },
      { day: "W3", calories: 11820 },
      { day: "W4", calories: 14190 }
    ],
    []
  );

  const macroSplit = useMemo(
    () => [
      { name: "Protein", value: 34, color: "#00FF94" },
      { name: "Carbs", value: 46, color: "#5B8CFF" },
      { name: "Fat", value: 20, color: "#FF6B35" }
    ],
    []
  );

  const [heroRef, heroVisible] = useInView<HTMLDivElement>(0.15);
  const [problemRef, problemVisible] = useInView<HTMLDivElement>(0.15);
  const [howRef, howVisible] = useInView<HTMLDivElement>(0.15);
  const [bentoRef, bentoVisible] = useInView<HTMLDivElement>(0.15);
  const [previewRef, previewVisible] = useInView<HTMLDivElement>(0.15);
  const [testRef, testVisible] = useInView<HTMLDivElement>(0.15);
  const [pricingRef, pricingVisible] = useInView<HTMLDivElement>(0.15);
  const [ctaRef, ctaVisible] = useInView<HTMLDivElement>(0.15);
  const [footerRef, footerVisible] = useInView<HTMLDivElement>(0.15);

  const statA = useCountUp(stats[0].value, 900, heroVisible);
  const statB = useCountUp(stats[1].value, 1100, heroVisible);
  const statC = useCountUp(stats[2].value, 900, heroVisible);

  const [typedFood, setTypedFood] = useState("");
  useEffect(() => {
    if (!bentoVisible) return;
    const text = "Rajma Rice";
    let i = 0;
    const id = window.setInterval(() => {
      i += 1;
      setTypedFood(text.slice(0, i));
      if (i >= text.length) window.clearInterval(id);
    }, 64);
    return () => window.clearInterval(id);
  }, [bentoVisible]);

  const updateUnderline = (index: number) => {
    const wrap = navWrapRef.current;
    const btn = navItemRefs.current[index];
    if (!wrap || !btn) return;
    const a = wrap.getBoundingClientRect();
    const b = btn.getBoundingClientRect();
    setUnderline({ left: b.left - a.left, width: b.width, opacity: 1 });
  };

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "start" });
    setMenuOpen(false);
  };

  const proMonthly = 99;
  const proYearly = Math.round(proMonthly * 12 * 0.8);

  const proPrice = pricingYearly ? proYearly : proMonthly;
  const proUnit = pricingYearly ? "/yr" : "/mo";

  return (
    <div
      className="min-h-screen text-[color:var(--text)]"
      style={{
        background: "var(--bg)",
        color: "var(--text)"
      }}
    >
      <style>{`
        @import url("https://fonts.googleapis.com/css2?family=Syne:wght@800&display=swap");

        :root{
          --bg:#050608;
          --surface:#0D0F12;
          --border:#1A1D23;
          --primary:#00FF94;
          --secondary:#FF6B35;
          --accent:#5B8CFF;
          --text:#F0F2F5;
          --muted:#6B7280;
        }

        html,body{background:var(--bg);}
        body{font-family:"Cabinet Grotesk", ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, "Helvetica Neue", Arial, "Noto Sans", "Apple Color Emoji","Segoe UI Emoji";}
        a,button{outline: none;}
        :focus-visible{box-shadow:0 0 0 3px rgba(0,255,148,0.28), 0 0 0 1px rgba(0,255,148,0.18);}

        @keyframes float{0%,100%{transform:translateY(0) translateX(0)}33%{transform:translateY(-20px) translateX(10px)}66%{transform:translateY(10px) translateX(-10px)}}
        @keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
        @keyframes sweep{0%{top:0%}100%{top:100%}}
        @keyframes marquee{0%{transform:translateX(0)}100%{transform:translateX(-50%)}}
        @keyframes pulse-ring{0%{transform:scale(1);opacity:1}100%{transform:scale(1.8);opacity:0}}
        @keyframes shimmer{0%{background-position:-200% 0}100%{background-position:200% 0}}
        @keyframes draw-line{from{stroke-dashoffset:1000}to{stroke-dashoffset:0}}
        @keyframes border-spin{0%{--angle:0deg}100%{--angle:360deg}}
        @keyframes grain{0%,100%{transform:translate(0,0)}10%{transform:translate(-2%,-3%)}30%{transform:translate(3%,2%)}50%{transform:translate(-1%,4%)}70%{transform:translate(2%,-2%)}90%{transform:translate(-3%,1%)}}
        @keyframes fadeSlideUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
        @keyframes scan-pulse{0%,100%{opacity:1}50%{opacity:0.3}}
        @keyframes nudge-right{0%,100%{transform:translateX(0)}50%{transform:translateX(6px)}}
        @keyframes underline-draw{from{stroke-dashoffset:300}to{stroke-dashoffset:0}}
        @keyframes shake{0%,100%{transform:translateX(0)}15%{transform:translateX(-2px)}30%{transform:translateX(2px)}45%{transform:translateX(-1px)}60%{transform:translateX(1px)}}

        .grain::before{
          content:"";
          position:fixed;
          inset:-30%;
          background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='.55'/%3E%3C/svg%3E");
          opacity:0.03;
          mix-blend-mode:overlay;
          pointer-events:none;
          animation:grain 8s steps(2,end) infinite;
        }

        .scanlines::after{
          content:"";
          position:absolute;
          inset:0;
          background:repeating-linear-gradient(to bottom, rgba(255,255,255,0.06), rgba(255,255,255,0.06) 1px, transparent 1px, transparent 4px);
          opacity:0.18;
          pointer-events:none;
          mask-image:radial-gradient(closest-side, rgba(0,0,0,0.95), transparent 70%);
        }

        .card{
          background:var(--surface);
          border:1px solid var(--border);
          box-shadow:0 0 0 1px #1A1D23, 0 0 20px rgba(0,255,148,0.04);
          transition:transform 250ms ease, box-shadow 250ms ease;
        }
        .card:hover{
          transform:translateY(-4px);
          box-shadow:0 0 0 1px #1A1D23, 0 0 30px rgba(0,255,148,0.15);
        }

        @media (prefers-reduced-motion: reduce){
          *{animation-duration:1ms !important;animation-iteration-count:1 !important;transition-duration:1ms !important;scroll-behavior:auto !important;}
        }
      `}</style>

      <div className="grain" />

      <div
        aria-hidden="true"
        className="pointer-events-none fixed left-0 top-0 z-[60] h-[400px] w-[400px] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{
          transform: `translate(${x}px, ${y}px) translate(-50%, -50%)`,
          background: "radial-gradient(circle, rgba(0,255,148,0.06), rgba(0,0,0,0) 62%)"
        }}
      />

      <header className="sticky top-0 z-50">
        <div
          className="border-b"
          style={{
            background: "rgba(5,6,8,0.80)",
            backdropFilter: "blur(18px)",
            borderColor: "rgba(26,29,35,0.8)"
          }}
        >
          <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
            <button
              type="button"
              onClick={() => scrollTo("home")}
              className="group inline-flex items-center gap-3 rounded-full px-2 py-1"
            >
              <span
                className="grid h-9 w-9 place-items-center rounded-xl border"
                style={{
                  background: "linear-gradient(180deg, rgba(0,255,148,0.14), rgba(0,0,0,0))",
                  borderColor: "rgba(26,29,35,0.9)"
                }}
              >
                <span
                  className="text-lg transition-transform duration-300 group-hover:rotate-[60deg]"
                  style={{ color: "var(--primary)" }}
                >
                  ⬡
                </span>
              </span>
              <span className="text-sm font-semibold tracking-[0.24em]">MessAI</span>
            </button>

            <div className="hidden items-center gap-8 md:flex">
              <div
                ref={navWrapRef}
                onMouseLeave={() => setUnderline((s) => ({ ...s, opacity: 0 }))}
                className="relative flex items-center gap-1 rounded-full px-2 py-1"
              >
                <div
                  aria-hidden="true"
                  className="absolute bottom-1 h-[2px] rounded-full transition-all duration-200"
                  style={{
                    left: underline.left,
                    width: underline.width,
                    opacity: underline.opacity,
                    background: "linear-gradient(90deg, rgba(0,255,148,0), rgba(0,255,148,0.9), rgba(0,255,148,0))"
                  }}
                />
                {nav.map((item, idx) => (
                  <button
                    key={item.id}
                    ref={(el) => {
                      navItemRefs.current[idx] = el;
                    }}
                    type="button"
                    onMouseEnter={() => updateUnderline(idx)}
                    onFocus={() => updateUnderline(idx)}
                    onClick={() => {
                      setActiveNav(item.label);
                      scrollTo(item.id);
                    }}
                    className="rounded-full px-3 py-2 text-xs font-medium tracking-wide transition-colors"
                    style={{
                      color: activeNav === item.label ? "var(--text)" : "rgba(240,242,245,0.72)"
                    }}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  className="rounded-full px-4 py-2 text-xs font-semibold"
                  style={{
                    color: "rgba(240,242,245,0.82)",
                    border: "1px solid rgba(26,29,35,0.9)"
                  }}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  className="group inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold"
                  style={{
                    background: "rgba(0,255,148,0.92)",
                    color: "#050608"
                  }}
                >
                  Start Free <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setMenuOpen(true)}
              className="inline-flex items-center justify-center rounded-xl border p-2 md:hidden"
              style={{ borderColor: "rgba(26,29,35,0.9)" }}
              aria-label="Open menu"
            >
              <Menu className="h-5 w-5" />
            </button>
          </div>
        </div>

        {menuOpen ? (
          <div
            className="fixed inset-0 z-[80] md:hidden"
            style={{
              background: "rgba(5,6,8,0.92)",
              backdropFilter: "blur(22px)"
            }}
            role="dialog"
            aria-modal="true"
          >
            <div className="mx-auto flex h-full max-w-6xl flex-col px-4">
              <div className="flex items-center justify-between py-4">
                <div className="inline-flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl border" style={{ borderColor: "rgba(26,29,35,0.9)" }}>
                    <span style={{ color: "var(--primary)" }}>⬡</span>
                  </span>
                  <span className="text-sm font-semibold tracking-[0.24em]">MessAI</span>
                </div>
                <button
                  type="button"
                  onClick={() => setMenuOpen(false)}
                  className="rounded-xl border p-2"
                  style={{ borderColor: "rgba(26,29,35,0.9)" }}
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="mt-8 flex flex-1 flex-col justify-between">
                <div className="space-y-2">
                  {nav.map((item, idx) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setActiveNav(item.label);
                        scrollTo(item.id);
                      }}
                      className="block w-full rounded-2xl border px-4 py-4 text-left text-lg font-semibold"
                      style={{
                        borderColor: "rgba(26,29,35,0.9)",
                        background: "rgba(13,15,18,0.65)",
                        animationName: "fadeSlideUp",
                        animationDuration: "700ms",
                        animationTimingFunction: "ease",
                        animationFillMode: "both",
                        animationDelay: `${idx * 0.08}s`
                      }}
                    >
                      <span className="inline-flex items-center justify-between">
                        <span>{item.label}</span>
                        <ChevronRight className="h-5 w-5" style={{ color: "rgba(240,242,245,0.65)" }} />
                      </span>
                    </button>
                  ))}
                </div>

                <div className="mb-8 grid gap-3">
                  <button
                    type="button"
                    className="w-full rounded-2xl px-5 py-4 text-sm font-semibold"
                    style={{
                      border: "1px solid rgba(26,29,35,0.9)",
                      color: "rgba(240,242,245,0.88)"
                    }}
                  >
                    Sign In
                  </button>
                  <button
                    type="button"
                    className="w-full rounded-2xl px-5 py-4 text-sm font-semibold"
                    style={{ background: "rgba(0,255,148,0.92)", color: "#050608" }}
                  >
                    Start Free →
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </header>

      <main>
        <section id="home" className="relative overflow-hidden">
          <div ref={heroRef} className="relative">
            <div aria-hidden="true" className="pointer-events-none absolute inset-0">
              <div
                className="absolute -left-20 top-[-80px] h-[420px] w-[420px] rounded-full blur-[120px]"
                style={{
                  opacity: 0.15,
                  background: "radial-gradient(circle, rgba(0,255,148,1), rgba(0,0,0,0) 65%)",
                  animation: "float 18s ease-in-out infinite"
                }}
              />
              <div
                className="absolute -right-24 top-[10px] h-[520px] w-[520px] rounded-full blur-[120px]"
                style={{
                  opacity: 0.15,
                  background: "radial-gradient(circle, rgba(91,140,255,1), rgba(0,0,0,0) 65%)",
                  animation: "float 24s ease-in-out infinite"
                }}
              />
            </div>

            <div className="scanlines relative mx-auto max-w-6xl px-4 pb-14 pt-10 md:pb-20 md:pt-16">
              <div className="grid items-center gap-10 md:grid-cols-12">
                <div className="md:col-span-7">
                  <div
                    className="inline-flex items-center gap-3 rounded-full border px-4 py-2 text-xs font-semibold tracking-wide"
                    style={{
                      borderColor: "rgba(26,29,35,0.9)",
                      background: "rgba(13,15,18,0.65)"
                    }}
                  >
                    <span className="relative flex h-2 w-2">
                      <span
                        className="absolute inline-flex h-full w-full rounded-full"
                        style={{ background: "rgba(0,255,148,0.35)", animation: "pulse-ring 1.35s ease-out infinite" }}
                      />
                      <span className="relative inline-flex h-2 w-2 rounded-full" style={{ background: "rgba(0,255,148,0.95)" }} />
                    </span>
                    ✦ AI-Powered · Free to Start
                  </div>

                  <h1
                    className="mt-5 text-4xl font-extrabold leading-[1.02] tracking-[-0.04em] md:text-6xl"
                    style={{ fontFamily: "Syne, ui-serif, Georgia, serif" }}
                  >
                    <span className={heroVisible ? "inline-block" : "inline-block opacity-0"} style={{ animation: heroVisible ? "fadeSlideUp 900ms ease both" : undefined }}>
                      Your Mess Food,
                    </span>
                    <br />
                    <span
                      className={heroVisible ? "relative inline-block italic" : "relative inline-block italic opacity-0"}
                      style={{ animation: heroVisible ? "fadeSlideUp 900ms ease both 80ms" : undefined }}
                    >
                      Finally
                      <svg
                        aria-hidden="true"
                        className="absolute -bottom-1 left-0 w-full"
                        height="14"
                        viewBox="0 0 320 14"
                        fill="none"
                      >
                        <path
                          d="M6 9C64 2 115 2 160 7C208 12 250 12 314 6"
                          stroke="rgba(0,255,148,0.95)"
                          strokeWidth="3"
                          strokeLinecap="round"
                          style={{
                            strokeDasharray: 300,
                            strokeDashoffset: heroVisible ? 0 : 300,
                            animation: heroVisible ? "underline-draw 1.1s ease both 350ms" : undefined
                          }}
                        />
                      </svg>
                    </span>
                    <br />
                    <span className={heroVisible ? "inline-block" : "inline-block opacity-0"} style={{ animation: heroVisible ? "fadeSlideUp 900ms ease both 140ms" : undefined }}>
                      Understood.
                    </span>
                  </h1>

                  <p
                    className="mt-5 max-w-xl text-sm leading-relaxed md:text-base"
                    style={{ color: "rgba(240,242,245,0.72)" }}
                  >
                    Snap a photo of today’s mess plate. MessAI estimates macros, spots gaps, and gives actionable
                    recommendations—fast enough to fit hostel life.
                  </p>

                  <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center">
                    <button
                      type="button"
                      className="group inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold"
                      style={{ background: "rgba(0,255,148,0.92)", color: "#050608" }}
                    >
                      Scan Your First Meal
                      <span className="inline-flex items-center" style={{ animation: "nudge-right 1.4s ease-in-out infinite" }}>
                        <ArrowRight className="h-4 w-4" />
                      </span>
                    </button>
                    <button
                      type="button"
                      className="group inline-flex items-center justify-center gap-2 rounded-full border px-6 py-3 text-sm font-semibold"
                      style={{
                        borderColor: "rgba(26,29,35,0.9)",
                        color: "rgba(240,242,245,0.88)",
                        background: "rgba(13,15,18,0.45)"
                      }}
                    >
                      <span className="relative inline-flex h-6 w-6 items-center justify-center rounded-full border" style={{ borderColor: "rgba(26,29,35,0.9)" }}>
                        <Play className="h-3.5 w-3.5" style={{ color: "rgba(240,242,245,0.75)" }} />
                        <span
                          className="absolute inset-0 rounded-full"
                          style={{ animation: "pulse-ring 1.6s ease-out infinite", boxShadow: "0 0 0 1px rgba(0,255,148,0.18)" }}
                        />
                      </span>
                      Watch Demo
                    </button>
                  </div>

                  <div className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs" style={{ color: "rgba(240,242,245,0.70)" }}>
                    <span className="inline-flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4" style={{ color: "rgba(0,255,148,0.85)" }} /> No credit card
                    </span>
                    <span className="inline-flex items-center gap-2">
                      <Sparkles className="h-4 w-4" style={{ color: "rgba(91,140,255,0.95)" }} /> Works on any meal
                    </span>
                    <span className="inline-flex items-center gap-2">
                      <Activity className="h-4 w-4" style={{ color: "rgba(255,107,53,0.95)" }} /> Results in 3s
                    </span>
                  </div>

                  <div className="mt-8 grid grid-cols-3 gap-4">
                    {[
                      { ...stats[0], value: statA, accent: "rgba(0,255,148,0.92)" },
                      { ...stats[1], value: statB, accent: "rgba(91,140,255,0.92)" },
                      { ...stats[2], value: statC, accent: "rgba(255,107,53,0.92)" }
                    ].map((s, i) => (
                      <div
                        key={s.label}
                        className="card rounded-2xl px-4 py-4"
                        style={{
                          animationName: heroVisible ? "fadeSlideUp" : undefined,
                          animationDuration: heroVisible ? "700ms" : undefined,
                          animationTimingFunction: heroVisible ? "ease" : undefined,
                          animationFillMode: heroVisible ? "both" : undefined,
                          animationDelay: heroVisible ? `${200 + i * 90}ms` : undefined
                        }}
                      >
                        <div className="text-xl font-extrabold tracking-tight" style={{ color: s.accent }}>
                          {s.value}
                          {s.suffix}
                        </div>
                        <div className="mt-1 text-[11px]" style={{ color: "rgba(240,242,245,0.62)" }}>
                          {s.label}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="md:col-span-5">
                  <div
                    className="relative mx-auto max-w-sm"
                    style={{
                      animation: heroVisible ? "fadeSlideUp 900ms ease both 160ms" : undefined,
                      opacity: heroVisible ? 1 : 0
                    }}
                  >
                    <div className="absolute -inset-8 rounded-[40px]" style={{ background: "radial-gradient(circle at 30% 30%, rgba(0,255,148,0.14), transparent 55%)" }} />

                    <div
                      className="relative mx-auto w-full rounded-[42px] border p-2"
                      style={{
                        borderColor: "rgba(26,29,35,0.9)",
                        background: "linear-gradient(180deg, rgba(13,15,18,0.9), rgba(5,6,8,0.65))"
                      }}
                    >
                      <div className="relative overflow-hidden rounded-[36px]" style={{ background: "rgba(8,9,11,0.9)" }}>
                        <div className="flex items-center justify-between px-4 py-3">
                          <div className="text-xs font-semibold tracking-wide" style={{ color: "rgba(240,242,245,0.78)" }}>
                            Scan meal
                          </div>
                          <div className="text-[11px]" style={{ color: "rgba(107,114,128,0.95)" }}>
                            21:07
                          </div>
                        </div>

                        <div className="relative mx-4 mb-4 h-64 overflow-hidden rounded-2xl border" style={{ borderColor: "rgba(26,29,35,0.9)" }}>
                          <div
                            aria-hidden="true"
                            className="absolute inset-0"
                            style={{
                              background:
                                "radial-gradient(circle at 20% 20%, rgba(91,140,255,0.18), transparent 55%), radial-gradient(circle at 70% 80%, rgba(0,255,148,0.16), transparent 60%), linear-gradient(180deg, rgba(13,15,18,0.2), rgba(5,6,8,0.9))"
                            }}
                          />

                          <div aria-hidden="true" className="absolute inset-0 opacity-80">
                            <div className="absolute left-3 top-3 h-7 w-7 rounded-[10px] border" style={{ borderColor: "rgba(0,255,148,0.45)", animation: "scan-pulse 1.3s ease-in-out infinite" }} />
                            <div className="absolute right-3 top-3 h-7 w-7 rounded-[10px] border" style={{ borderColor: "rgba(0,255,148,0.45)", animation: "scan-pulse 1.3s ease-in-out infinite 120ms" }} />
                            <div className="absolute bottom-3 left-3 h-7 w-7 rounded-[10px] border" style={{ borderColor: "rgba(0,255,148,0.45)", animation: "scan-pulse 1.3s ease-in-out infinite 240ms" }} />
                            <div className="absolute bottom-3 right-3 h-7 w-7 rounded-[10px] border" style={{ borderColor: "rgba(0,255,148,0.45)", animation: "scan-pulse 1.3s ease-in-out infinite 360ms" }} />
                          </div>

                          <div
                            aria-hidden="true"
                            className="absolute left-0 right-0 h-[2px]"
                            style={{
                              background: "linear-gradient(90deg, transparent, rgba(0,255,148,0.85), transparent)",
                              boxShadow: "0 0 20px rgba(0,255,148,0.25)",
                              animation: "sweep 2s linear infinite"
                            }}
                          />
                        </div>

                        <div className="mx-4 mb-4 space-y-3">
                          <div className="flex flex-wrap gap-2">
                            {[
                              { t: "🔥 482 kcal", d: "0s", c: "rgba(255,107,53,0.16)", b: "rgba(255,107,53,0.35)" },
                              { t: "💪 34g Protein", d: "0.2s", c: "rgba(0,255,148,0.14)", b: "rgba(0,255,148,0.35)" },
                              { t: "🌾 51g Carbs", d: "0.35s", c: "rgba(91,140,255,0.14)", b: "rgba(91,140,255,0.35)" },
                              { t: "⚡ 12g Fat", d: "0.55s", c: "rgba(240,242,245,0.06)", b: "rgba(240,242,245,0.18)" }
                            ].map((chip) => (
                              <span
                                key={chip.t}
                                className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold"
                                style={{
                                  background: chip.c,
                                  borderColor: chip.b,
                                  color: "rgba(240,242,245,0.88)",
                                  animationName: "bob",
                                  animationDuration: "3s",
                                  animationTimingFunction: "ease-in-out",
                                  animationIterationCount: "infinite",
                                  animationDelay: chip.d
                                }}
                              >
                                {chip.t}
                              </span>
                            ))}
                          </div>

                          <div className="rounded-2xl border px-4 py-3" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.65)" }}>
                            <div className="flex items-center justify-between text-xs font-semibold" style={{ color: "rgba(240,242,245,0.78)" }}>
                              <span>AI Processing…</span>
                              <span style={{ color: "rgba(0,255,148,0.85)" }}>3s</span>
                            </div>
                            <div className="mt-2 h-2 overflow-hidden rounded-full" style={{ background: "rgba(26,29,35,0.9)" }}>
                              <div
                                className="h-full w-full"
                                style={{
                                  background: "linear-gradient(90deg, rgba(0,255,148,0.15), rgba(0,255,148,0.85), rgba(91,140,255,0.35))",
                                  backgroundSize: "200% 100%",
                                  animation: "shimmer 1.3s linear infinite"
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="border-y" style={{ borderColor: "rgba(26,29,35,0.75)" }}>
          <div className="overflow-hidden">
            <div
              className="flex w-[200%] items-center py-4"
              style={{
                animation: "marquee 20s linear infinite"
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLDivElement).style.animationPlayState = "paused";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLDivElement).style.animationPlayState = "running";
              }}
            >
              {[0, 1].map((setIdx) => (
                <div key={setIdx} className="flex w-1/2 items-center justify-around gap-6 px-6">
                  {marquee.map((m) => (
                    <div key={`${setIdx}-${m}`} className="inline-flex items-center gap-3 whitespace-nowrap text-xs font-semibold tracking-wide">
                      <span style={{ color: "rgba(0,255,148,0.95)" }}>✦</span>
                      <span style={{ color: "rgba(240,242,245,0.78)" }}>{m}</span>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="problem" className="mx-auto max-w-6xl px-4 py-14 md:py-20">
          <div
            ref={problemRef}
            className="grid gap-6 md:grid-cols-12"
            style={{ opacity: problemVisible ? 1 : 0, transform: problemVisible ? "translateY(0)" : "translateY(30px)", transition: "all 800ms ease" }}
          >
            <div className="card relative overflow-hidden rounded-3xl p-6 md:col-span-5">
              <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(255,107,53,0.95)" }}>
                THE PROBLEM
              </div>
              <div className="mt-3 text-2xl font-extrabold tracking-tight">Mess food is a black box.</div>
              <div className="mt-2 text-sm" style={{ color: "rgba(240,242,245,0.68)" }}>
                🥲 You’re optimizing your health, but your plate never comes with labels.
              </div>

              <div className="mt-6 space-y-3">
                {[
                  "No idea what’s actually in today’s mess curry",
                  "Hard to hit protein goals consistently",
                  "Generic diet advice ignores your real food"
                ].map((t) => (
                  <div key={t} className="flex items-start gap-3 rounded-2xl border px-4 py-3" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)" }}>
                    <span className="mt-0.5 text-sm font-extrabold" style={{ color: "rgba(255,107,53,0.95)" }}>
                      ✗
                    </span>
                    <div className="text-sm" style={{ color: "rgba(240,242,245,0.76)" }}>
                      {t}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative flex md:col-span-2">
              <div className="mx-auto hidden h-full w-[2px] md:block" style={{ background: "linear-gradient(to bottom, rgba(0,255,148,0), rgba(0,255,148,0.7), rgba(0,255,148,0))" }} />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0 hidden md:block"
                style={{
                  clipPath: "polygon(45% 0%, 55% 0%, 100% 100%, 0% 100%)",
                  background: "radial-gradient(circle at 50% 50%, rgba(0,255,148,0.12), transparent 60%)"
                }}
              />
            </div>

            <div className="card relative overflow-hidden rounded-3xl p-6 md:col-span-5">
              <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(0,255,148,0.95)" }}>
                MESSAI FIXES THIS
              </div>
              <div className="mt-3 text-2xl font-extrabold tracking-tight">Turn guesswork into signals.</div>
              <div className="mt-2 text-sm" style={{ color: "rgba(240,242,245,0.68)" }}>
                Your plate becomes data. Your day becomes a plan.
              </div>

              <div className="mt-6 space-y-3">
                {[
                  "Scan meals for estimated macros in seconds",
                  "Spot protein gaps and deficiency risks early",
                  "Get AI advice tailored to hostel constraints"
                ].map((t) => (
                  <div key={t} className="flex items-start gap-3 rounded-2xl border px-4 py-3" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)" }}>
                    <span className="mt-0.5 text-sm font-extrabold" style={{ color: "rgba(0,255,148,0.95)" }}>
                      ✓
                    </span>
                    <div className="text-sm" style={{ color: "rgba(240,242,245,0.76)" }}>
                      {t}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section id="how" className="mx-auto max-w-6xl px-4 pb-14 md:pb-20">
          <div ref={howRef} className="flex items-end justify-between gap-6">
            <div>
              <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(91,140,255,0.92)" }}>
                HOW IT WORKS
              </div>
              <h2 className="mt-3 text-3xl font-extrabold tracking-tight md:text-4xl">Scan. Understand. Improve.</h2>
            </div>
            <div className="hidden text-sm md:block" style={{ color: "rgba(240,242,245,0.62)" }}>
              Minimal friction. Maximum clarity.
            </div>
          </div>

          <div className="relative mt-10">
            <svg
              aria-hidden="true"
              className="absolute left-0 top-8 hidden w-full md:block"
              height="44"
              viewBox="0 0 1000 44"
              fill="none"
            >
              <path
                d="M30 22H970"
                stroke="rgba(0,255,148,0.45)"
                strokeWidth="2"
                style={{
                  strokeDasharray: "7 8",
                  strokeDashoffset: howVisible ? 0 : 1000,
                  animation: howVisible ? "draw-line 1.2s ease both" : undefined
                }}
              />
            </svg>

            <div className="grid gap-6 md:grid-cols-3">
              {[
                {
                  n: "01",
                  icon: <Camera className="h-5 w-5" />,
                  title: "Snap your plate",
                  desc: "Use your phone camera. MessAI handles messy lighting and angles.",
                  mini: <div className="mt-4 inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}><span style={{ color: "rgba(0,255,148,0.9)" }}>Scanning</span><span className="h-1.5 w-1.5 rounded-full" style={{ background: "rgba(0,255,148,0.9)" }} /></div>
                },
                {
                  n: "02",
                  icon: <BarChart3 className="h-5 w-5" />,
                  title: "Extract nutrition",
                  desc: "Estimate calories and macros, plus confidence hints you can trust.",
                  mini: <div className="mt-4 grid grid-cols-3 gap-2 text-[11px]"><span className="rounded-full border px-2 py-1" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)" }}>kcal</span><span className="rounded-full border px-2 py-1" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)" }}>P</span><span className="rounded-full border px-2 py-1" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)" }}>C</span></div>
                },
                {
                  n: "03",
                  icon: <MessageSquare className="h-5 w-5" />,
                  title: "Get AI insights",
                  desc: "Personalized recommendations that fit hostel constraints and your goals.",
                  mini: <div className="mt-4 inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-semibold" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}><span style={{ color: "rgba(91,140,255,0.9)" }}>Tip:</span><span style={{ color: "rgba(240,242,245,0.75)" }}>Add curd</span></div>
                }
              ].map((s, i) => (
                <div
                  key={s.n}
                  className="card rounded-3xl p-6"
                  style={{
                    opacity: howVisible ? 1 : 0,
                    transform: howVisible ? "translateY(0)" : "translateY(30px)",
                    transition: "all 850ms ease",
                    transitionDelay: `${i * 110}ms`
                  }}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="text-4xl font-extrabold tracking-tight" style={{ fontFamily: "Syne, ui-serif, Georgia, serif", color: "rgba(0,255,148,0.22)" }}>
                      {s.n}
                    </div>
                    <div className="grid h-10 w-10 place-items-center rounded-2xl border" style={{ borderColor: "rgba(0,255,148,0.35)", background: "rgba(0,255,148,0.10)", color: "rgba(0,255,148,0.95)" }}>
                      {s.icon}
                    </div>
                  </div>
                  <div className="mt-4 text-lg font-extrabold tracking-tight">{s.title}</div>
                  <div className="mt-2 text-sm leading-relaxed" style={{ color: "rgba(240,242,245,0.68)" }}>
                    {s.desc}
                  </div>
                  {s.mini}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="features" className="mx-auto max-w-6xl px-4 pb-14 md:pb-20">
          <div
            ref={bentoRef}
            className="grid gap-6"
            style={{ opacity: bentoVisible ? 1 : 0, transform: bentoVisible ? "translateY(0)" : "translateY(30px)", transition: "all 850ms ease" }}
          >
            <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
              <div>
                <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(0,255,148,0.92)" }}>
                  FEATURES
                </div>
                <h2 className="mt-3 text-3xl font-extrabold tracking-tight md:text-4xl">A bento box of utility.</h2>
              </div>
              <div className="text-sm" style={{ color: "rgba(240,242,245,0.62)" }}>
                Built for the realities of campus food.
              </div>
            </div>

            <div className="grid gap-6 md:grid-cols-2">
              <div className="card relative overflow-hidden rounded-3xl p-6 md:row-span-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-extrabold tracking-tight">AI Meal Scanner</div>
                  <div className="rounded-full border px-3 py-1 text-xs font-semibold" style={{ borderColor: "rgba(0,255,148,0.35)", color: "rgba(0,255,148,0.92)" }}>
                    Live
                  </div>
                </div>
                <div className="mt-3 text-sm" style={{ color: "rgba(240,242,245,0.68)" }}>
                  Detection box + meal name materializing in real-time.
                </div>

                <div className="relative mt-6 h-48 overflow-hidden rounded-2xl border" style={{ borderColor: "rgba(26,29,35,0.9)" }}>
                  <div
                    className="absolute inset-0"
                    style={{
                      background:
                        "radial-gradient(circle at 35% 30%, rgba(0,255,148,0.16), transparent 60%), radial-gradient(circle at 70% 70%, rgba(91,140,255,0.14), transparent 60%), linear-gradient(180deg, rgba(13,15,18,0.2), rgba(5,6,8,0.9))"
                    }}
                  />
                  <div className="absolute left-6 top-6 h-24 w-32 rounded-2xl border" style={{ borderColor: "rgba(0,255,148,0.55)" }} />
                  <div className="absolute left-0 right-0 h-[2px]" style={{ animation: "sweep 2s linear infinite", background: "linear-gradient(90deg, transparent, rgba(0,255,148,0.85), transparent)", boxShadow: "0 0 22px rgba(0,255,148,0.25)" }} />
                  <div className="absolute bottom-5 left-5 rounded-full border px-4 py-2 text-sm font-extrabold" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.68)" }}>
                    <span style={{ color: "rgba(0,255,148,0.9)" }}>{typedFood || " "}</span>
                    <span className="ml-1 opacity-60" style={{ color: "rgba(240,242,245,0.72)" }}>
                      {typedFood.length < 9 ? "▍" : ""}
                    </span>
                  </div>
                </div>
              </div>

              <div className="card rounded-3xl p-6 md:col-span-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-extrabold tracking-tight">Nutrition Dashboard</div>
                  <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.60)" }}>
                    Week snapshot
                  </div>
                </div>
                <div className="mt-5 h-44 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={weekCalories} margin={{ left: 0, right: 0, top: 4, bottom: 0 }}>
                      <defs>
                        <linearGradient id="gCal" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="rgba(0,255,148,0.75)" />
                          <stop offset="100%" stopColor="rgba(0,255,148,0)" />
                        </linearGradient>
                      </defs>
                      <CartesianGrid stroke="rgba(26,29,35,0.55)" vertical={false} />
                      <XAxis dataKey="day" tick={{ fill: "rgba(240,242,245,0.55)", fontSize: 12 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: "rgba(240,242,245,0.45)", fontSize: 12 }} axisLine={false} tickLine={false} width={36} />
                      <Tooltip {...tooltipProps} />
                      <Area type="monotone" dataKey="calories" stroke="rgba(0,255,148,0.9)" strokeWidth={2} fill="url(#gCal)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="card rounded-3xl p-6">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-extrabold tracking-tight">TDEE Calculator</div>
                  <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.60)" }}>
                    Progress
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-4">
                  <div className="relative h-16 w-16">
                    <svg className="h-16 w-16 -rotate-90" viewBox="0 0 100 100">
                      <circle cx="50" cy="50" r="40" stroke="rgba(26,29,35,0.9)" strokeWidth="12" fill="none" />
                      <circle
                        cx="50"
                        cy="50"
                        r="40"
                        stroke="rgba(0,255,148,0.9)"
                        strokeWidth="12"
                        fill="none"
                        strokeLinecap="round"
                        strokeDasharray={2 * Math.PI * 40}
                        strokeDashoffset={2 * Math.PI * 40 * (1 - 0.73)}
                        style={{ transition: "stroke-dashoffset 900ms ease" }}
                      />
                    </svg>
                    <div className="absolute inset-0 grid place-items-center text-sm font-extrabold" style={{ color: "rgba(0,255,148,0.92)" }}>
                      73%
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.62)" }}>
                      Calories/day
                    </div>
                    <div className="mt-1 text-xl font-extrabold tracking-tight">2,200</div>
                    <div className="mt-1 text-xs" style={{ color: "rgba(240,242,245,0.62)" }}>
                      Protein target suggested automatically.
                    </div>
                  </div>
                </div>
              </div>

              <div className="card rounded-3xl p-6">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-extrabold tracking-tight">Deficiency Alerts</div>
                  <div className="text-xs font-semibold" style={{ color: "rgba(255,107,53,0.9)" }}>
                    Today
                  </div>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  {[
                    { t: "Low Protein ⚠", c: "rgba(255,107,53,0.18)", b: "rgba(255,107,53,0.35)" },
                    { t: "High Carbs", c: "rgba(91,140,255,0.14)", b: "rgba(91,140,255,0.35)" },
                    { t: "Hydration", c: "rgba(240,242,245,0.06)", b: "rgba(240,242,245,0.18)" }
                  ].map((a) => (
                    <span
                      key={a.t}
                      className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold"
                      style={{ background: a.c, borderColor: a.b, color: "rgba(240,242,245,0.88)", animation: a.t.includes("⚠") ? "shake 1.4s ease-in-out infinite" : undefined }}
                    >
                      {a.t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="card rounded-3xl p-6">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-extrabold tracking-tight">Allergy Filter</div>
                  <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.60)" }}>
                    Tags
                  </div>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  {[
                    { t: "Lactose ✗", c: "rgba(255,107,53,0.14)", b: "rgba(255,107,53,0.35)", strike: true },
                    { t: "Gluten ✗", c: "rgba(255,107,53,0.10)", b: "rgba(255,107,53,0.25)", strike: true },
                    { t: "Nuts ✓", c: "rgba(0,255,148,0.12)", b: "rgba(0,255,148,0.32)", strike: false },
                    { t: "Egg ✓", c: "rgba(91,140,255,0.12)", b: "rgba(91,140,255,0.32)", strike: false }
                  ].map((tag) => (
                    <span
                      key={tag.t}
                      className="inline-flex items-center rounded-full border px-3 py-1 text-xs font-semibold"
                      style={{
                        background: tag.c,
                        borderColor: tag.b,
                        color: "rgba(240,242,245,0.88)",
                        textDecoration: tag.strike ? "line-through" : "none",
                        textDecorationThickness: "2px",
                        textDecorationColor: "rgba(240,242,245,0.38)"
                      }}
                    >
                      {tag.t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="card overflow-hidden rounded-3xl p-6 md:col-span-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-extrabold tracking-tight">AI Recommendations</div>
                  <div className="text-xs font-semibold" style={{ color: "rgba(91,140,255,0.9)" }}>
                    Chat preview
                  </div>
                </div>
                <div className="mt-5 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="grid h-9 w-9 place-items-center rounded-2xl border" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(0,255,148,0.10)", color: "rgba(0,255,148,0.95)" }}>
                      ⬡
                    </div>
                    <div className="flex-1">
                      <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.70)" }}>
                        MessAI Bot
                      </div>
                      <div className="mt-2 w-fit rounded-2xl border px-4 py-3 text-sm" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)", color: "rgba(240,242,245,0.82)" }}>
                        <span className="inline-flex items-center gap-1">
                          <span className="h-1.5 w-1.5 rounded-full" style={{ background: "rgba(240,242,245,0.55)" }} />
                          <span className="h-1.5 w-1.5 rounded-full" style={{ background: "rgba(240,242,245,0.55)" }} />
                          <span className="h-1.5 w-1.5 rounded-full" style={{ background: "rgba(240,242,245,0.55)" }} />
                        </span>
                      </div>
                      {[
                        "Your lunch was carb-heavy. Add curd or eggs tonight to balance protein.",
                        "You’re 38g short on protein today. Paneer + dal is the easiest mess combo."
                      ].map((m, idx) => (
                        <div
                          key={m}
                          className="mt-3 w-fit rounded-2xl border px-4 py-3 text-sm"
                          style={{
                            borderColor: "rgba(26,29,35,0.9)",
                            background: "rgba(13,15,18,0.55)",
                            color: "rgba(240,242,245,0.82)",
                            animationName: bentoVisible ? "fadeSlideUp" : undefined,
                            animationDuration: bentoVisible ? "700ms" : undefined,
                            animationTimingFunction: bentoVisible ? "ease" : undefined,
                            animationFillMode: bentoVisible ? "both" : undefined,
                            animationDelay: bentoVisible ? `${idx * 180 + 220}ms` : undefined
                          }}
                        >
                          {m}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 pb-14 md:pb-20">
          <div
            ref={previewRef}
            className="card group relative overflow-hidden rounded-[32px] p-4 md:p-6"
            style={{
              opacity: previewVisible ? 1 : 0,
              transform: previewVisible ? "translateY(0)" : "translateY(30px)",
              transition: "all 850ms ease"
            }}
          >
            <div className="mb-4 flex items-center justify-between">
              <div className="inline-flex items-center gap-2">
                <span className="h-3 w-3 rounded-full" style={{ background: "rgba(255,107,53,0.9)" }} />
                <span className="h-3 w-3 rounded-full" style={{ background: "rgba(240,242,245,0.25)" }} />
                <span className="h-3 w-3 rounded-full" style={{ background: "rgba(0,255,148,0.9)" }} />
              </div>
              <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(240,242,245,0.62)" }}>
                LIVE DASHBOARD PREVIEW
              </div>
            </div>

            <div
              className="overflow-hidden rounded-[28px] border transition-transform duration-500 group-hover:scale-[1.01]"
              style={{
                borderColor: "rgba(26,29,35,0.9)",
                transform: "perspective(1200px) rotateX(6deg)",
                transformOrigin: "center top",
                transition: "transform 420ms ease"
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLDivElement).style.transform = "perspective(1200px) rotateX(0deg)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLDivElement).style.transform = "perspective(1200px) rotateX(6deg)";
              }}
            >
              <div className="grid md:grid-cols-[12rem_1fr]">
                <aside className="border-r p-4" style={{ borderColor: "rgba(26,29,35,0.85)", background: "rgba(5,6,8,0.25)" }}>
                  <div className="flex items-center gap-3">
                    <div className="grid h-10 w-10 place-items-center rounded-2xl border" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(0,255,148,0.10)", color: "rgba(0,255,148,0.95)" }}>
                      ⬡
                    </div>
                    <div>
                      <div className="text-sm font-extrabold tracking-tight">MessAI</div>
                      <div className="text-xs" style={{ color: "rgba(240,242,245,0.62)" }}>
                        Student mode
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 space-y-2 text-sm">
                    {[
                      { icon: <LayoutGrid className="h-4 w-4" />, t: "Dashboard", active: true },
                      { icon: <Camera className="h-4 w-4" />, t: "Meals", active: false },
                      { icon: <Flame className="h-4 w-4" />, t: "Goals", active: false },
                      { icon: <Activity className="h-4 w-4" />, t: "Profile", active: false }
                    ].map((it) => (
                      <button
                        key={it.t}
                        type="button"
                        className="flex w-full items-center gap-3 rounded-2xl px-3 py-2 text-left"
                        style={{
                          background: it.active ? "rgba(0,255,148,0.12)" : "transparent",
                          color: it.active ? "rgba(240,242,245,0.92)" : "rgba(240,242,245,0.70)",
                          borderLeft: it.active ? "3px solid rgba(0,255,148,0.9)" : "3px solid transparent"
                        }}
                      >
                        <span style={{ color: it.active ? "rgba(0,255,148,0.92)" : "rgba(240,242,245,0.55)" }}>{it.icon}</span>
                        {it.t}
                      </button>
                    ))}
                  </div>
                </aside>

                <div className="p-4 md:p-6">
                  <div className="flex flex-col items-start justify-between gap-3 md:flex-row md:items-center">
                    <div>
                      <div className="text-xl font-extrabold tracking-tight">Good evening, Rahul 👋</div>
                      <div className="text-xs" style={{ color: "rgba(240,242,245,0.62)" }}>
                        Fri · 29 Apr
                      </div>
                    </div>

                    <div className="inline-flex rounded-full border p-1 text-xs font-semibold" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}>
                      {(["Week", "Month"] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setDashTab(t)}
                          className="rounded-full px-3 py-2"
                          style={{
                            color: dashTab === t ? "#050608" : "rgba(240,242,245,0.72)",
                            background: dashTab === t ? "rgba(0,255,148,0.92)" : "transparent"
                          }}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="mt-5 grid gap-4 md:grid-cols-3">
                    {[
                      { t: "Today's Calories", v: "1,840/2,200", p: 0.84, c: "rgba(0,255,148,0.92)" },
                      { t: "Protein", v: "67/120g", p: 0.56, c: "rgba(91,140,255,0.92)" },
                      { t: "Water", v: "1.8/2.5L", p: 0.72, c: "rgba(240,242,245,0.82)" }
                    ].map((k) => (
                      <div key={k.t} className="rounded-3xl border p-4" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}>
                        <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.62)" }}>
                          {k.t}
                        </div>
                        <div className="mt-1 text-lg font-extrabold tracking-tight">{k.v}</div>
                        <div className="mt-3 h-2 overflow-hidden rounded-full" style={{ background: "rgba(26,29,35,0.9)" }}>
                          <div className="h-full rounded-full" style={{ width: `${k.p * 100}%`, background: k.c }} />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_18rem]">
                    <div className="rounded-3xl border p-4" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-extrabold tracking-tight">Weekly calories</div>
                        <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.60)" }}>
                          {dashTab}
                        </div>
                      </div>
                      <div className="mt-4 h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={dashTab === "Week" ? weekCalories : monthCalories} margin={{ left: 0, right: 0, top: 4, bottom: 0 }}>
                            <defs>
                              <linearGradient id="gDash" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="rgba(0,255,148,0.7)" />
                                <stop offset="100%" stopColor="rgba(0,255,148,0)" />
                              </linearGradient>
                            </defs>
                            <CartesianGrid stroke="rgba(26,29,35,0.55)" vertical={false} />
                            <XAxis dataKey="day" tick={{ fill: "rgba(240,242,245,0.55)", fontSize: 12 }} axisLine={false} tickLine={false} />
                            <YAxis tick={{ fill: "rgba(240,242,245,0.45)", fontSize: 12 }} axisLine={false} tickLine={false} width={36} />
                            <Tooltip {...tooltipProps} />
                            <Area type="monotone" dataKey="calories" stroke="rgba(0,255,148,0.9)" strokeWidth={2} fill="url(#gDash)" />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                    </div>

                    <div className="rounded-3xl border p-4" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-extrabold tracking-tight">Macro split</div>
                        <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.60)" }}>
                          Today
                        </div>
                      </div>
                      <div className="mt-2 h-48">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Tooltip {...tooltipProps} />
                            <Pie data={macroSplit} dataKey="value" nameKey="name" innerRadius={46} outerRadius={72} paddingAngle={2}>
                              {macroSplit.map((m) => (
                                <Cell key={m.name} fill={m.color} />
                              ))}
                            </Pie>
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="mt-2 space-y-2 text-xs">
                        {macroSplit.map((m) => (
                          <div key={m.name} className="flex items-center justify-between">
                            <div className="inline-flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full" style={{ background: m.color }} />
                              <span style={{ color: "rgba(240,242,245,0.72)" }}>{m.name}</span>
                            </div>
                            <span style={{ color: "rgba(240,242,245,0.72)" }}>{m.value}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_18rem]">
                    <div className="rounded-3xl border p-4" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-extrabold tracking-tight">Today’s Meals</div>
                        <button type="button" className="rounded-full border px-3 py-1 text-xs font-semibold" style={{ borderColor: "rgba(26,29,35,0.9)", color: "rgba(240,242,245,0.68)" }}>
                          View all
                        </button>
                      </div>
                      <div className="mt-4 overflow-hidden rounded-2xl border" style={{ borderColor: "rgba(26,29,35,0.9)" }}>
                        <table className="w-full text-left text-xs">
                          <thead style={{ background: "rgba(5,6,8,0.25)" }}>
                            <tr>
                              <th className="px-3 py-3 font-semibold" style={{ color: "rgba(240,242,245,0.68)" }}>
                                Meal
                              </th>
                              <th className="px-3 py-3 font-semibold" style={{ color: "rgba(240,242,245,0.68)" }}>
                                Time
                              </th>
                              <th className="px-3 py-3 font-semibold" style={{ color: "rgba(240,242,245,0.68)" }}>
                                Macros
                              </th>
                              <th className="px-3 py-3" />
                            </tr>
                          </thead>
                          <tbody>
                            {[
                              { n: "Dal Chawal", kcal: 480, t: "08:40", e: "🍛" },
                              { n: "Rajma Rice", kcal: 620, t: "13:20", e: "🍲" },
                              { n: "Banana", kcal: 89, t: "17:15", e: "🍌" }
                            ].map((row) => (
                              <tr key={row.n} className="border-t" style={{ borderColor: "rgba(26,29,35,0.9)" }}>
                                <td className="px-3 py-3">
                                  <span className="inline-flex items-center gap-2">
                                    <span>{row.e}</span>
                                    <span className="font-semibold" style={{ color: "rgba(240,242,245,0.82)" }}>
                                      {row.n}
                                    </span>
                                  </span>
                                </td>
                                <td className="px-3 py-3" style={{ color: "rgba(240,242,245,0.62)" }}>
                                  {row.t}
                                </td>
                                <td className="px-3 py-3" style={{ color: "rgba(240,242,245,0.62)" }}>
                                  {row.kcal}kcal
                                </td>
                                <td className="px-3 py-3 text-right">
                                  <button type="button" className="rounded-full border px-3 py-1 text-xs font-semibold" style={{ borderColor: "rgba(26,29,35,0.9)", color: "rgba(240,242,245,0.62)" }}>
                                    Delete
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    <div className="rounded-3xl border p-4" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}>
                      <div className="flex items-center justify-between">
                        <div className="text-sm font-extrabold tracking-tight">AI Insights</div>
                        <span className="rounded-full border px-3 py-1 text-xs font-semibold" style={{ borderColor: "rgba(255,107,53,0.35)", background: "rgba(255,107,53,0.12)", color: "rgba(255,107,53,0.92)", animation: "pulse-ring 1.6s ease-out infinite" }}>
                          Protein Alert
                        </span>
                      </div>
                      <div className="mt-4 space-y-3 text-sm">
                        <div className="rounded-2xl border px-4 py-3" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)", color: "rgba(240,242,245,0.78)" }}>
                          Add curd or eggs at dinner to close your protein gap.
                        </div>
                        <div className="rounded-2xl border px-4 py-3" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(5,6,8,0.25)", color: "rgba(240,242,245,0.78)" }}>
                          Keep rice slightly lower next meal; you’re trending high on carbs.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 pb-14 md:pb-20">
          <div ref={testRef} style={{ opacity: testVisible ? 1 : 0, transform: testVisible ? "translateY(0)" : "translateY(30px)", transition: "all 850ms ease" }}>
            <div className="flex items-end justify-between gap-6">
              <div>
                <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(91,140,255,0.92)" }}>
                  TESTIMONIALS
                </div>
                <h2 className="mt-3 text-3xl font-extrabold tracking-tight md:text-4xl">Built for real mess life.</h2>
              </div>
            </div>

            <div className="mt-8 grid gap-6 md:grid-cols-3">
              {[
                { n: "Ananya", c: "I stopped guessing protein. The AI tips are insanely practical.", p: "IIT Delhi · 2nd year", i: "A", col: "rgba(0,255,148,0.9)" },
                { n: "Rahul", c: "The dashboard makes hostel food feel trackable for the first time.", p: "NIT Trichy · 3rd year", i: "R", col: "rgba(91,140,255,0.9)" },
                { n: "Sanya", c: "Quick scan + clear macros. It fits my schedule between classes.", p: "BITS Pilani · 1st year", i: "S", col: "rgba(255,107,53,0.9)" }
              ].map((t, idx) => (
                <div
                  key={t.n}
                  className="card rounded-3xl p-6"
                  style={{
                    animationName: testVisible ? "fadeSlideUp" : undefined,
                    animationDuration: testVisible ? "800ms" : undefined,
                    animationTimingFunction: testVisible ? "ease" : undefined,
                    animationFillMode: testVisible ? "both" : undefined,
                    animationDelay: testVisible ? `${idx * 120}ms` : undefined
                  }}
                >
                  <div className="flex items-center gap-3">
                    <div className="grid h-11 w-11 place-items-center rounded-2xl border text-sm font-extrabold" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)", color: t.col }}>
                      {t.i}
                    </div>
                    <div>
                      <div className="text-sm font-extrabold">{t.n}</div>
                      <div className="text-xs" style={{ color: "rgba(240,242,245,0.60)" }}>
                        {t.p}
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-1" style={{ color: "rgba(255,203,90,0.95)" }}>
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <div className="mt-4 text-sm italic leading-relaxed" style={{ color: "rgba(240,242,245,0.78)" }}>
                    “{t.c}”
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="pricing" className="mx-auto max-w-6xl px-4 pb-14 md:pb-20">
          <div
            ref={pricingRef}
            style={{ opacity: pricingVisible ? 1 : 0, transform: pricingVisible ? "translateY(0)" : "translateY(30px)", transition: "all 850ms ease" }}
          >
            <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
              <div>
                <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(0,255,148,0.92)" }}>
                  PRICING
                </div>
                <h2 className="mt-3 text-3xl font-extrabold tracking-tight md:text-4xl">Start free. Upgrade when it clicks.</h2>
              </div>

              <div className="inline-flex items-center gap-3 rounded-full border px-3 py-2 text-xs font-semibold" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)" }}>
                <button
                  type="button"
                  onClick={() => setPricingYearly(false)}
                  className="rounded-full px-3 py-1"
                  style={{ background: !pricingYearly ? "rgba(0,255,148,0.92)" : "transparent", color: !pricingYearly ? "#050608" : "rgba(240,242,245,0.72)" }}
                >
                  Monthly
                </button>
                <button
                  type="button"
                  onClick={() => setPricingYearly(true)}
                  className="rounded-full px-3 py-1"
                  style={{ background: pricingYearly ? "rgba(0,255,148,0.92)" : "transparent", color: pricingYearly ? "#050608" : "rgba(240,242,245,0.72)" }}
                >
                  Yearly (Save 20%)
                </button>
              </div>
            </div>

            <div className="mt-8 grid gap-6 md:grid-cols-2">
              <div className="card relative overflow-hidden rounded-3xl p-6">
                <div className="text-sm font-extrabold tracking-tight">Free</div>
                <div className="mt-2 text-sm" style={{ color: "rgba(240,242,245,0.68)" }}>
                  Enough to build the habit.
                </div>
                <div className="mt-6 flex items-baseline gap-2">
                  <div className="text-4xl font-extrabold">₹0</div>
                  <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.62)" }}>
                    forever
                  </div>
                </div>

                <div className="mt-6 space-y-3 text-sm">
                  {[
                    { ok: true, t: "Unlimited scans (basic accuracy)" },
                    { ok: true, t: "Daily calorie and macro estimate" },
                    { ok: true, t: "Simple AI tip of the day" },
                    { ok: false, t: "Deficiency alerts" },
                    { ok: false, t: "Advanced dashboard + exports" }
                  ].map((f) => (
                    <div key={f.t} className="flex items-start gap-3">
                      <span className="mt-0.5 text-sm font-extrabold" style={{ color: f.ok ? "rgba(0,255,148,0.95)" : "rgba(240,242,245,0.32)" }}>
                        {f.ok ? "✓" : "✗"}
                      </span>
                      <div style={{ color: f.ok ? "rgba(240,242,245,0.78)" : "rgba(240,242,245,0.42)" }}>{f.t}</div>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  className="mt-8 w-full rounded-2xl border px-5 py-3 text-sm font-semibold"
                  style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)", color: "rgba(240,242,245,0.88)" }}
                >
                  Start Free
                </button>
              </div>

              <div className="card relative overflow-hidden rounded-3xl p-6" style={{ borderColor: "rgba(0,255,148,0.35)" }}>
                <div
                  className="absolute -right-16 top-8 h-44 w-44 rounded-full blur-[70px]"
                  style={{ background: "radial-gradient(circle, rgba(0,255,148,0.16), transparent 60%)" }}
                />
                <div
                  className="absolute right-3 top-3 rotate-45 rounded-md px-3 py-1 text-[11px] font-extrabold tracking-[0.18em]"
                  style={{ background: "rgba(0,255,148,0.92)", color: "#050608" }}
                >
                  MOST POPULAR
                </div>
                <div className="text-sm font-extrabold tracking-tight">Pro</div>
                <div className="mt-2 text-sm" style={{ color: "rgba(240,242,245,0.68)" }}>
                  Precision, alerts, and a real plan.
                </div>
                <div className="mt-6 flex items-baseline gap-2">
                  <div className="text-4xl font-extrabold">₹{proPrice}</div>
                  <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.62)" }}>
                    {proUnit}
                  </div>
                  {pricingYearly ? (
                    <div className="ml-2 text-xs font-semibold" style={{ color: "rgba(240,242,245,0.45)" }}>
                      <span style={{ textDecoration: "line-through" }}>₹{proMonthly * 12}</span>
                    </div>
                  ) : null}
                </div>

                <div className="mt-6 space-y-3 text-sm">
                  {[
                    "Higher-accuracy scan + confidence hints",
                    "Deficiency alerts and protein gap tracking",
                    "Smart recommendations (mess-aware)",
                    "Advanced dashboard insights",
                    "Priority model upgrades"
                  ].map((t) => (
                    <div key={t} className="flex items-start gap-3">
                      <span className="mt-0.5 text-sm font-extrabold" style={{ color: "rgba(0,255,148,0.95)" }}>
                        ✓
                      </span>
                      <div style={{ color: "rgba(240,242,245,0.78)" }}>{t}</div>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  className="relative mt-8 w-full overflow-hidden rounded-2xl px-5 py-3 text-sm font-semibold"
                  style={{
                    background: "rgba(0,255,148,0.92)",
                    color: "#050608"
                  }}
                >
                  Upgrade to Pro
                </button>
              </div>
            </div>
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-4 pb-14 md:pb-20">
          <div
            ref={ctaRef}
            className="relative overflow-hidden rounded-[32px] border p-8 md:p-12"
            style={{
              borderColor: "rgba(26,29,35,0.9)",
              background: "radial-gradient(circle at 50% 40%, rgba(0,255,148,0.18), rgba(13,15,18,0.72) 55%, rgba(5,6,8,0.85))",
              opacity: ctaVisible ? 1 : 0,
              transform: ctaVisible ? "translateY(0)" : "translateY(30px)",
              transition: "all 850ms ease"
            }}
          >
            <div className="max-w-2xl">
              <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(0,255,148,0.92)" }}>
                READY
              </div>
              <h2 className="mt-3 text-3xl font-extrabold tracking-tight md:text-4xl">Stop Guessing. Start Knowing.</h2>
              <p className="mt-3 text-sm leading-relaxed md:text-base" style={{ color: "rgba(240,242,245,0.72)" }}>
                Join 500+ students already eating smarter—with data that respects mess reality.
              </p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
                <button
                  type="button"
                  className="relative inline-flex items-center justify-center rounded-full px-6 py-3 text-sm font-semibold"
                  style={{
                    background:
                      "conic-gradient(from var(--angle), rgba(0,255,148,0.0), rgba(0,255,148,0.95), rgba(91,140,255,0.65), rgba(0,255,148,0.0))",
                    animation: "border-spin 2.4s linear infinite"
                  }}
                >
                  <span className="absolute inset-[2px] rounded-full" style={{ background: "rgba(0,255,148,0.92)" }} />
                  <span className="relative inline-flex items-center gap-2" style={{ color: "#050608" }}>
                    Start Free <ArrowRight className="h-4 w-4" />
                  </span>
                </button>
                <div className="text-xs font-semibold" style={{ color: "rgba(240,242,245,0.62)" }}>
                  Join 500+ students already eating smarter.
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer id="footer" className="border-t" style={{ borderColor: "rgba(26,29,35,0.85)" }}>
        <div ref={footerRef} className="mx-auto max-w-6xl px-4 py-12" style={{ opacity: footerVisible ? 1 : 0, transform: footerVisible ? "translateY(0)" : "translateY(30px)", transition: "all 850ms ease" }}>
          <div className="grid gap-8 md:grid-cols-4">
            <div className="md:col-span-1">
              <div className="inline-flex items-center gap-3">
                <span className="grid h-10 w-10 place-items-center rounded-2xl border" style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(0,255,148,0.10)", color: "rgba(0,255,148,0.95)" }}>
                  ⬡
                </span>
                <div>
                  <div className="text-sm font-extrabold tracking-tight">MessAI</div>
                  <div className="text-xs" style={{ color: "rgba(240,242,245,0.62)" }}>
                    AI nutrition for students
                  </div>
                </div>
              </div>

              <div className="mt-5 flex items-center gap-3">
                {[
                  { Icon: Sparkles, label: "Twitter" },
                  { Icon: MessageSquare, label: "Instagram" },
                  { Icon: BarChart3, label: "LinkedIn" }
                ].map(({ Icon, label }) => (
                  <button
                    key={label}
                    type="button"
                    className="rounded-xl border p-2"
                    style={{ borderColor: "rgba(26,29,35,0.9)", background: "rgba(13,15,18,0.55)", color: "rgba(240,242,245,0.78)" }}
                    aria-label={label}
                  >
                    <Icon className="h-4 w-4" />
                  </button>
                ))}
              </div>
            </div>

            {[
              { h: "Product", l: ["Scanner", "Dashboard", "AI Insights", "Pricing"] },
              { h: "Company", l: ["About", "Careers", "Contact", "Press"] },
              { h: "Legal", l: ["Privacy", "Terms", "Security", "Status"] }
            ].map((col) => (
              <div key={col.h}>
                <div className="text-xs font-semibold tracking-[0.22em]" style={{ color: "rgba(240,242,245,0.62)" }}>
                  {col.h.toUpperCase()}
                </div>
                <div className="mt-4 space-y-2">
                  {col.l.map((t) => (
                    <button
                      key={t}
                      type="button"
                      className="group block text-left text-sm"
                      style={{ color: "rgba(240,242,245,0.72)" }}
                    >
                      <span className="relative">
                        {t}
                        <span
                          aria-hidden="true"
                          className="absolute -bottom-0.5 left-0 h-[2px] w-full scale-x-0 rounded-full transition-transform duration-200 group-hover:scale-x-100"
                          style={{ background: "rgba(0,255,148,0.85)", transformOrigin: "left" }}
                        />
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10 border-t pt-6 text-xs" style={{ borderColor: "rgba(26,29,35,0.85)", color: "rgba(240,242,245,0.62)" }}>
            <div className="flex flex-col justify-between gap-2 md:flex-row md:items-center">
              <div>© {new Date().getFullYear()} MessAI. All rights reserved.</div>
              <div>Made with 💚 for students.</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
